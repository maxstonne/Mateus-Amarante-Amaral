CREATE TABLE destino (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(50) not null,
    descricao VARCHAR(50) not null,
    turismo DOUBLE not null,
    custo DOUBLE not null
);
select * from destino;